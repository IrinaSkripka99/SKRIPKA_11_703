package ru.itis.repositories;

import ru.itis.models.Basket;
import ru.itis.models.BasketOrder;
import ru.itis.models.User;

import java.util.List;

public interface BasketRepository extends CrudRepository<Basket> {
    void addProduct(Long product, Long basket);

    Basket createCookieBasket(User user);

    List<BasketOrder> getProducts(Long basketId);

    /* Basket findByCookieValue(String cookieValue);*/
    Basket getBasket(User user);

}
