package ru.itis.services;

import ru.itis.models.BasketOrder;
import ru.itis.models.Basket;
import ru.itis.models.User;

import java.util.List;


public interface BasketService {
    List<BasketOrder> addProductToUserBasket(Basket basket, Long productId);
    Basket createBasket(User user);
    List<BasketOrder> getProduct(Long basketId);
    Basket getBasket(User user);
}
